
const menuBtn = document.getElementById('menuBtn');
const mainNav = document.getElementById('mainNav');
if(menuBtn && mainNav){
  menuBtn.addEventListener('click',()=>mainNav.classList.toggle('open'));
  document.querySelectorAll('#mainNav a').forEach(a=>{
    a.addEventListener('click',()=>mainNav.classList.remove('open'));
  });
}
