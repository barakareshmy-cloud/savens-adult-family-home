# SAVENS Adult Family Home website

This project contains six separate pages:
- Home
- About
- Services
- Our Home
- Gallery
- Contact

The supplied exterior car photo was intentionally excluded because the license plate is visible.
The homepage currently uses the neighborhood photo as the hero image.
